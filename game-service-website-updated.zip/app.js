
function sendOTP() {
    const phoneNumber = document.getElementById("phoneNumber").value;
    if (phoneNumber) {
        alert("OTP sent to " + phoneNumber);
        document.querySelector('.otp-box').style.display = 'block';
    } else {
        alert("Please enter a valid mobile number.");
    }
}

function verifyOTP() {
    const otp = document.getElementById("otpCode").value;
    if (otp === "1234") { 
        alert("OTP verified! Redirecting to Home Page...");
        document.getElementById("loginPage").style.display = "none";
        document.getElementById("homePage").style.display = "block";
    } else {
        alert("Invalid OTP. Try again!");
    }
}

function payWithPhonePe() {
    alert("Redirecting to PhonePe for payment...");
}

function payWithPaytm() {
    alert("Redirecting to Paytm for payment...");
}
